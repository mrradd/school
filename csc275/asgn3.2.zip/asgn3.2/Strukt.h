/*******************************************************************************
* Struct: Strukt */
/**
* Just a class to demonstrate a struct.
*******************************************************************************/
#include <iostream>
struct Strukt
  {
  public:
    static int counter;
           int number;
  
  public:
    Strukt();
    ~Strukt();
  };