/*******************************************************************************
* Class: Clazz */
/**
* Just a class to demonstrate classy-ness.
*******************************************************************************/
#include <iostream>
class Clazz
  {
  public:
    static int counter;
           int number;
  public:
    Clazz();
    ~Clazz();
  };