#include "BMICalculator.h"

/**
Conrad Horton
CSC215 (May 2016)
20160512
Assignment 1.1 - BMI Calculator
**/

int main(int argc, char* argv[])
  {
  BMICalculator::loop();
  return 0;
  }