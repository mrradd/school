#include "BMICalculator.h"

int main(int argc, char* argv[])
  {
  BMICalculator::loop();
  return 0;
  }