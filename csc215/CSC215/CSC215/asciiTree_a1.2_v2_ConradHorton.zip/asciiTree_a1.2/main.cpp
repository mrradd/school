#include "a1_2/ASCIITree.h"

/**
Conrad Horton
CSC215 (May 2016)
20160511
Assignment 1.2 - ASCII Tree
**/

int main(int argc, char* argv[])
  {
  ASCIITree::loop();

  //WINDOWS ONLY
  system("pause");

  return 0;
  }