#include "a1_2/ASCIITree.h"

int main(int argc, char* argv[])
  {
  ASCIITree::loop();

  //WINDOWS ONLY
  system("pause");

  return 0;
  }