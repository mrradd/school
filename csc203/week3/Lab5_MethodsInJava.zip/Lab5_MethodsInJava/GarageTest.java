
/*******************************************************************************
* Conrad Horton
* CSC203 June 2016
* Lab5 Assignment: Garage Test Program
* 20160629
********************************************************************************
* Test class for Garage.
*******************************************************************************/
package rad;

class GarageTest
  {  
  public static void main (String[] args)
    {
    new Garage().addCars();
    }
  }